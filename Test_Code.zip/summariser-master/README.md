# Automatic Text Summariser
Summarises text input by copy/paste, file upload or url link. The % of text summarised can be altered. The estimated reading times of the input and output are both displayed.

Run the auto text summariser by running the [wsgi.py] app