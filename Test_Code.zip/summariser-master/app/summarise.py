import spacy, nltk, requests
import validators
from bs4 import BeautifulSoup
from pathlib import Path
from gensim.summarization.summarizer import summarize 
from gensim.summarization import keywords
nltk.download('punkt')
nlp = spacy.load("en_core_web_sm")

# Get the text from url
def text_from_url(url):
    valid = validators.url(url)
    if valid:
        html_text = requests.get(url).text
        soup = BeautifulSoup(html_text) # contains all html text
        all_paras = soup.find_all('p') # get all paragraphs
        text = ''
        for para in all_paras:
            text += para.text
        return text
    else:
        return None
def text_from_file(path):
    ...

def cleanse_data(text):
    # remove whitespace
    text = text.replace(r'\s+', " ") 
    # Remove chars \n and \t
    text = text.replace(r'\\n', ' ')
    text = text.replace(r'\\t', ' ')
    # Remove non-English characters from text
    text = text.replace(r'[^\x00-\x7F]+', '')
    # Remove some comment code, anything between and including <!– and –>
    text = text.replace("<!--.*-->","")
    # TODO: Contractions? 
    return text # return tokenised sentences

def readingTime(text):
    total_words = len([token.text for token in nlp(text)])
    # Average human readnig time is approx 250 wpm
    estimated_time = total_words/200
    return estimated_time

def summarise_text(text):
    clean_text = cleanse_data(text)
    summarised_text = summarize(clean_text,ratio=0.3)
    print(summarised_text)
    return summarised_text
