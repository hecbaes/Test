from flask import Flask, render_template, request, redirect, url_for
from nltk.metrics.distance import jaccard_distance
# import form
from werkzeug.utils import secure_filename

import spacy, nltk, requests
import validators
from bs4 import BeautifulSoup
from pathlib import Path
from rouge import Rouge 
import os
import pandas as pd
from gensim.summarization.summarizer import summarize 
from gensim.summarization import keywords
from nltk.metrics.distance import jaccard_distance
from nltk.util import ngrams
nltk.download('punkt')
nlp = spacy.load("en_core_web_sm")
rouge = Rouge()

UPLOAD_FOLDER = 'static/files'
ALLOWED_EXTENSIONS = {'txt','pdf','csv'}

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

input = ""
summarised_text = ""
reading_time=0
summary_percentage = ""
output_reading_time = 0
f1=0
precision=0
recall=0


@app.route("/", methods = ["GET","POST"])
def index():
    return render_template("main.html",output_reading_time=0, reading_time=0)

@app.route("/", methods = ["GET","POST"])
def allowed_file(filename):
    return '.' in filename and \
        filename.rsplit('.',1)[1].lower() in ALLOWED_EXTENSIONS

@app.route("/summarise", methods = ["GET","POST"])
def summarise():
    global input, summary_percentage, ratio, reading_time, summarised_text, output_reading_time, f1, precision, recall, jac
    if request.method == "POST":
        input = request.form.get('input')
        summary_percentage = request.form.get('ratio')
        ratio = float(summary_percentage)/100.0
        reading_time = readingTime(input)
        summarised_text = summarise_text(input,ratio)
        summary_percentage = round(len(summarised_text)/len(input)*100)
        # Calculate reading time
        output_reading_time = readingTime(summarised_text)
        # Evaluate the current summary
        scores = evaluate(input, summarised_text)
        f1 = round(scores[0]['rouge-2']['f'],3)
        precision = round(scores[0]['rouge-2']['p'],3)
        recall = round(scores[0]['rouge-2']['r'],3)
        jac = round(jaccard(input,summarised_text),3)
        accuracy = get_accuracy(jac)
        return render_template("main.html",input=input, output_reading_time=output_reading_time, output=summarised_text,reading_time=reading_time, summary_percentage=summary_percentage, f1=f1, precision=precision, recall=recall, jac=jac, accuracy=accuracy)

@app.route("/upload-url", methods = ["GET","POST"])
def upload_url():
    # TODO: Add error handling
    if request.method == "POST":
        url = request.form.get("url")
        # Extract text from url
        input = text_from_url(url)
        # Inproper URL
        if input == None:
            return render_template("main.html",input="Invalid URL", reading_time="0", output_reading_time="0")
        # Calculate reading time
        reading_time = readingTime(input)
        return render_template("main.html", input=input, reading_time=reading_time, output="", output_reading_time="0")

@app.route("/upload-file", methods = ["POST"])
def upload_file():
    if request.method == "POST":
        if request.files:
            f = request.files["file"]
            # if user selects a file
            if f.filename != "":
                # Save image
                # f.save(secure_filename(f.filename))
                contents = f.read().decode("utf-8") 
                contents = cleanse_data(contents)
                reading_time = readingTime(contents)
            return render_template("main.html", input=contents, reading_time=reading_time, output="", output_reading_time="0")
    return render_template('/upload-file')

@app.route("/find", methods=["POST"])
def find_scores():
    scores = {}
    print("yes")
    for p in range(0,100,5):
        print(p)
        per = p/100
        ref = summarise_text(input,per)
        # add score to table if summary yields a result
        if not ref == "":
            score = rouge.get_scores(input,ref)
            jacc = jaccard(input,ref)
            accuracy = get_accuracy(jacc)
            average = (score[0]['rouge-2']['f']+score[0]['rouge-2']['p']+score[0]['rouge-2']['r'])/3
            scores[p] = [score[0]['rouge-2']['f'],score[0]['rouge-2']['p'],score[0]['rouge-2']['r'],average,jacc,accuracy]
            print(scores[p])
    cols = ['f1_score','precision','recall','average','jaccard_distance','accuracy']
    # print(scores)
    print()
    table = pd.DataFrame.from_dict(scores,orient='index',columns=cols).to_html()
    print(f'text: {input}')
    return render_template("main.html",input=input, output_reading_time=output_reading_time, output=summarised_text,reading_time=reading_time, summary_percentage=summary_percentage, f1=f1, precision=precision, recall=recall, jac=jac, accuracy=accuracy, table=table)
    # hyp = {}
    # f1_score = {}
    # precision = {}
    # recall = {}
    # rouge_scores = {}
    # for p in range(0,100,5):

    #     col = f'Summary_{p}'
    #     hyp[p] = master_df[col]
    #     score = rouge.get_scores(hyp[p], ref)
    #     # create custom variable names in a dictionary for each column name
    #     f1_score[p] = f'f1_score_{p}'
    #     precision[p] = f'precision_{p}'
    #     recall[p] = f'recall_{p}'
    #     rouge_scores_p = [score[0]['rouge-2']['f'],score[0]['rouge-2']['p'],score[0]['rouge-2']['r']]
    #     columns = [f1_score[p],precision[p], recall[p]]
    #     rouge_scores[p] = pd.DataFrame(rouge_scores_p, columns=columns)
    # rouge_df =  pd.concat(rouge_scores.values, axis=1)

# Get the text from url
def text_from_url(url):
    valid = validators.url(url)
    if valid:
        html_text = requests.get(url).text
        soup = BeautifulSoup(html_text) # contains all html text
        all_paras = soup.find_all('p') # get all paragraphs
        text = ''
        for para in all_paras:
            text += para.text
        return text
    else:
        return None
def text_from_file(path):
    ...

def cleanse_data(text):
    # remove whitespace
    text = text.replace(r'\s+', " ") 
    # Remove chars \n and \t
    text = text.replace(r'\\n', ' ')
    text = text.replace(r'\\t', ' ')
    # Remove non-English characters from text
    text = text.replace(r'[^\x00-\x7F]+', '')
    # Remove some comment code, anything between and including <!– and –>
    text = text.replace("<!--.*-->","")
    # TODO: Contractions? 
    return text

def readingTime(text):
    total_words = len([token.text for token in nlp(text)])
    # Average human reading time is approx 200 wpm
    estimated_time = total_words/200
    return estimated_time

def summarise_text(text, ratio):
    clean_text = cleanse_data(text)
    try:
        summarised_text = summarize(clean_text,ratio=ratio)
        return summarised_text
    except(ValueError):   
        return "More text needed for input"    

# Return the f1, precision and recall score of a summarised text
def evaluate(reference, hypothesis):
    score = rouge.get_scores(hypothesis, reference)
    return score

# Return the jaccard distance score of a summarised text with its original
# Jaccard distances is a measure of the dissimilarity between two texts
def jaccard(reference,hypothesis):
    ref_list = nltk.word_tokenize(reference)
    hyp_list = nltk.word_tokenize(hypothesis)
    ref_tokens = set(nltk.ngrams(ref_list,n=2))
    hyp_tokens = set(nltk.ngrams(hyp_list,n=2))
    jaccard = 1-nltk.jaccard_distance(ref_tokens, hyp_tokens)
    return jaccard

# Return an accuracy category given a jaccard score
def get_accuracy(jaccard_score):
    # Cutoffs for accuracy score 
    VERY_HIGH = 0.8
    HIGH = 0.7
    MEDIUM = 0.5
    LOW = 0.3
    if jaccard_score < LOW:
        return "Low"
    elif jaccard_score < MEDIUM:
        return "Medium"
    elif jaccard_score < HIGH:
        return "High"
    elif jaccard_score < VERY_HIGH:
        return "Very High"
    

if __name__ == "__main__":
    app.run()