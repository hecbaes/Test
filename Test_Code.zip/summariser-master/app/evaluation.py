# Precision and Recall
from rouge import Rouge 
import pandas as pd
import numpy as np
import re
from pathlib import Path
import nltk
nltk.download('punkt')
import glob
from nltk.metrics.distance import jaccard_distance
from nltk.util import ngrams
from nltk.metrics.distance  import edit_distance
# Creating summaries and reference variables for ROUGE scoring

ref = master_df['Ref']
rouge = Rouge()

# List of percentages to be used for the summary
percentages = [70,80,90]
hyp = {}
f1_score = {}
precision = {}
recall = {}
rouge_scores = []

# create dictionary of the hypotheses and scores from each summary percentage
for p in percentages:
    col = f'Summary_{p}'
    hyp[p] = master_df[col]
    score = rouge.get_scores(hyp[p], ref)
    # create custom variable names in a dictionary for each column name
    f1_score[p] = f'f1_score_{p}'
    precision[p] = f'precision_{p}'
    recall[p] = f'recall_{p}'
    rouge_scores_p = [score[0]['rouge-2']['f'],score[0]['rouge-2']['p'],score[0]['rouge-2']['r']]
    columns = [f1_score[p],precision[p], recall[p]]
    rouge_scores[p] = pd.DataFrame(rouge_scores_p, columns=columns)

rouge_df =  pd.concat(rouge_scores.values, axis=1)