percent = 90

variable = f'Summary_{percent}'
hyp={}
hyp[percent]=variable



print(hyp[90])

rouge_scores90 =[]
for item in scores_90:
    f1_score_90 = item['rouge-2']['f']
    precision_90 = item['rouge-2']['p']
    recall_90 = item['rouge-2']['r']
    rouge_scores90.append([f1_score_90, precision_90, recall_90])
    